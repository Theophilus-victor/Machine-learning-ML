import json

def load_mood_data():
    """ Load predefined mood data from a JSON file """
    with open("data/mood_data.json", "r") as file:
        mood_data = json.load(file)
    return mood_data
