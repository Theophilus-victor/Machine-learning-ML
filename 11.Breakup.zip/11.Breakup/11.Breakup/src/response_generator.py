import requests
import os

API_KEY = os.getenv("AIML_API_KEY", "7950c21c84b94c7cb68b80ba609333c0")
API_URL = "https://api.aimlapi.com/v1/chat/completions"
PREFERRED_MODEL = "gpt-4o"
FALLBACK_MODELS = ["gpt-3.5-turbo", "mistral"]

def generate_response(user_message, history=None):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    system_prompt = (
        "You are a caring and supportive best friend. Respond in a natural, emotionally intelligent way. "
        "You're not a therapist or an AI—just someone who's here to listen and comfort your friend who's feeling heartbroken."
    )

    messages = [{"role": "system", "content": system_prompt}]
    
    # Add conversation history if available
    if history:
        messages.extend(history)
    
    messages.append({"role": "user", "content": user_message})

    data = {
        "model": PREFERRED_MODEL,
        "messages": messages,
        "temperature": 0.9,
    }

    try:
        response = requests.post(API_URL, headers=headers, json=data)
        response.raise_for_status()
        reply = response.json()["choices"][0]["message"]["content"]
        return reply.strip()
    except Exception as e:
        return "Sorry, I'm having trouble responding right now. Let's try again in a moment."
