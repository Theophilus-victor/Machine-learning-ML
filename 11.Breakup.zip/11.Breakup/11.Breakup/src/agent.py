from .response_generator import generate_response

class FriendAgent:
    def process_message(self, message, history=None):
        return generate_response(message, history)
