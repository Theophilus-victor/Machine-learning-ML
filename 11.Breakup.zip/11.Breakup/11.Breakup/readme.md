Sure! Here's a professional and friendly README.md for your Breakup Support Chatbot project, updated to reflect the use of the AIML API with natural conversational tone:

README.md

# 💔 Breakup Support Chatbot

A supportive, empathetic, and emotionally intelligent chatbot that talks to you like a caring friend during tough times—especially breakups. Built using Python and integrated with the AIML API for realistic, human-like responses.

✨ Features

- 🧠 Empathetic responses like a real friend
- 💬 Keeps natural conversation flow with history
- 🔄 Supports restart/clear of chat history
- 🚪 Exit command to leave the chat
- 🤖 Powered by AIML API (gpt-4o, with fallback to gpt-3.5-turbo and mistral)

🛠️ Tech Stack

- Python 3.x
- AIML API (https://api.aimlapi.com)
- Terminal/Command-line interface

📁 Project Structure

.
├── main.py                 # Entry point (terminal chat app)
├── src/
│   ├── agent.py           # FriendAgent class handling message processing
│   └── response_generator.py  # Handles AIML API calls
├── README.md              # This file
└── requirements.txt       # Required Python packages

🚀 Getting Started

1. Clone this repository:

git clone https://github.com/your-username/breakup-support-chatbot.git
cd breakup-support-chatbot

2. Set up a virtual environment (optional but recommended):

python -m venv env
source env/bin/activate   # macOS/Linux
env\Scripts\activate      # Windows

3. Install dependencies:

pip install -r requirements.txt

4. Run the chatbot:

python main.py

5. Sample Commands:

- Type your message to chat
- Type cls to clear the conversation history
- Type exit to quit the chat

🔑 API Key Setup

The AIML API key is already configured with a fallback in the code:

response_generator.py

API_KEY = os.getenv("AIML_API_KEY", "2c2a55ec37ad46e28cca2e9f5dc0ca7e")

Optionally, you can set your API key via environment variable:

For Windows:

set AIML_API_KEY=your-api-key

For macOS/Linux:

export AIML_API_KEY=your-api-key

💡 Example Conversation

Friend Agent: Hey, I'm here to listen. How are you feeling today?

You: I just broke up with someone I really loved.

Friend Agent: Oh no, I'm so sorry you're going through this. That must really hurt. I'm here for you—want to tell me what happened?

📦 requirements.txt

requests

📝 License

This project is open-source and free to use for personal and educational purposes.

🤗 Credits

Developed by Sathisvar (with support from AIML API). Designed to help people feel heard, one conversation at a time.

Need help or have ideas to make it better? Just reach out!

Let me know if you'd like to publish it on GitHub—I can help generate a repository structure and .gitignore too.