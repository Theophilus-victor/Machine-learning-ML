import os

# AIML API configuration
API_KEY = os.getenv("AIML_API_KEY", "2c2a55ec37ad46e28cca2e9f5dc0ca7e")
API_URL = "https://api.aimlapi.com/v1/chat/completions"
PREFERRED_MODEL = "gpt-4o"
FALLBACK_MODELS = ["gpt-3.5-turbo", "mistral"]
