from src.agent import FriendAgent

agent = FriendAgent()
history = []

print("Friend Agent: Hey, I'm here to listen. How are you feeling today?")

while True:
    user_input = input("\nYou: ").strip().lower()

    if user_input in ["exit", "quit", "bye"]:
        print("Friend Agent: Take care. I'm always here if you need to talk.")
        break
    elif user_input == "cls":
        history = []
        print("Friend Agent: Conversation cleared. Feel free to start fresh.")
        continue

    response = agent.process_message(user_input, history)
    print("\nFriend Agent:", response)
    history.append({"role": "user", "content": user_input})
    history.append({"role": "assistant", "content": response})
